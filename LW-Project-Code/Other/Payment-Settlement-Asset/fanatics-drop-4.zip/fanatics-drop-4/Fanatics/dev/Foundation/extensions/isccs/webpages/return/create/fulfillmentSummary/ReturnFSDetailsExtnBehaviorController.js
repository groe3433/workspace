


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/return/create/fulfillmentSummary/ReturnFSDetailsExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnFSDetailsExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.return.create.fulfillmentSummary.ReturnFSDetailsExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.return.create.fulfillmentSummary.ReturnFSDetailsExtn'

			
			
			
}
);
});

