


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/home/portlets/OrderPortletExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnOrderPortletExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.home.portlets.OrderPortletExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.home.portlets.OrderPortletExtn'

			
			
			
}
);
});

