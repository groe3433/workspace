scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/search/OrderSearchExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderSearchExtnUI
){ 
	return _dojodeclare("extn.order.search.OrderSearchExtn", [_extnOrderSearchExtnUI],{
	// custom code here
});
});

