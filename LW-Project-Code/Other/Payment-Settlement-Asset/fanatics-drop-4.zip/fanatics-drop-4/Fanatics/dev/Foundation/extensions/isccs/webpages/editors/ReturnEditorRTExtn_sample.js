scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/editors/ReturnEditorRTExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnEditorRTExtnUI
){ 
	return _dojodeclare("extn.editors.ReturnEditorRTExtn", [_extnReturnEditorRTExtnUI],{
	// custom code here
});
});

