
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/payment/confirmation/PaymentConfirmationExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnPaymentConfirmationExtnUI
){ 
	return _dojodeclare("extn.payment.confirmation.PaymentConfirmationExtn", [_extnPaymentConfirmationExtnUI],{
	// custom code here
});
});

