scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/details/OrderTotalExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderTotalExtnUI
){ 
	return _dojodeclare("extn.order.details.OrderTotalExtn", [_extnOrderTotalExtnUI],{
	// custom code here
});
});

