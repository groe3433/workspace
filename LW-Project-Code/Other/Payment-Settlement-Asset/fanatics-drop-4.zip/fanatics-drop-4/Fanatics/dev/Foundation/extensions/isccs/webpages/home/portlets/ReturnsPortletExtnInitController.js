


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/home/portlets/ReturnsPortletExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnsPortletExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.home.portlets.ReturnsPortletExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.home.portlets.ReturnsPortletExtn'

			
			
			
}
);
});

