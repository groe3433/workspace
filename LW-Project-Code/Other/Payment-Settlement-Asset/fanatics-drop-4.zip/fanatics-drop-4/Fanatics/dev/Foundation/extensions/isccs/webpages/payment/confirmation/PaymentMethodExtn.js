
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/payment/confirmation/PaymentMethodExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnPaymentMethodExtnUI
){ 
	return _dojodeclare("extn.payment.confirmation.PaymentMethodExtn", [_extnPaymentMethodExtnUI],{
	// custom code here
});
});

