


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/common/address/capture/AddressCapturePageExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnAddressCapturePageExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.common.address.capture.AddressCapturePageExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.common.address.capture.AddressCapturePageExtn'

			
			
			
}
);
});

