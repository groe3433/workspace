


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/order/details/OrderTotalExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnOrderTotalExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.order.details.OrderTotalExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.order.details.OrderTotalExtn',

			 mashupRefs : 	[
	 		{
		 		extnType : 			'ADD',
		 		mashupId : 			'extn_OrderTotal_getCompleteOrderDetails',
		 		mashupRefId : 			'extn_OrderTotal_getCompleteOrderDetails'
	 		}

			]			
			
			
}
);
});

