scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/return/create/fulfillmentSummary/ReturnFSDetailsExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnFSDetailsExtnUI
){ 
	return _dojodeclare("extn.return.create.fulfillmentSummary.ReturnFSDetailsExtn", [_extnReturnFSDetailsExtnUI],{
	// custom code here
});
});

