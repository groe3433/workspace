


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/return/create/fulfillmentSummary/ReturnFSShippingGroupExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnFSShippingGroupExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.return.create.fulfillmentSummary.ReturnFSShippingGroupExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.return.create.fulfillmentSummary.ReturnFSShippingGroupExtn'

			
			
			
}
);
});

