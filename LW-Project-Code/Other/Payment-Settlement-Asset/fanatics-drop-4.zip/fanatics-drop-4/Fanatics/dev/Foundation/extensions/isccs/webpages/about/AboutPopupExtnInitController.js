


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/about/AboutPopupExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnAboutPopupExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.about.AboutPopupExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.about.AboutPopupExtn'

			
			
			
}
);
});

