
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/fulfillmentSummary/CarrierServicePopupExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnCarrierServicePopupExtnUI
){ 
	return _dojodeclare("extn.order.fulfillmentSummary.CarrierServicePopupExtn", [_extnCarrierServicePopupExtnUI],{
	// custom code here
});
});

