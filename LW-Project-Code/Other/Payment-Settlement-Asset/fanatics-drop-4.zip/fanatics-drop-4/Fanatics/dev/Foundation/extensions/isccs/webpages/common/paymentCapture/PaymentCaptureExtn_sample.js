scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/common/paymentCapture/PaymentCaptureExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnPaymentCaptureExtnUI
){ 
	return _dojodeclare("extn.common.paymentCapture.PaymentCaptureExtn", [_extnPaymentCaptureExtnUI],{
	// custom code here
});
});

