
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/cancel/CancelOrderBaseScreenExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnCancelOrderBaseScreenExtnUI
){ 
	return _dojodeclare("extn.order.cancel.CancelOrderBaseScreenExtn", [_extnCancelOrderBaseScreenExtnUI],{
	// custom code here
});
});

