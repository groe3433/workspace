
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/return/details/ReturnSummaryLinesExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnSummaryLinesExtnUI
){ 
	return _dojodeclare("extn.return.details.ReturnSummaryLinesExtn", [_extnReturnSummaryLinesExtnUI],{
	// custom code here
});
});

