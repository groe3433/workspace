scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/common/paymentCapture/PaymentCapture_CreditCardExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnPaymentCapture_CreditCardExtnUI
){ 
	return _dojodeclare("extn.common.paymentCapture.PaymentCapture_CreditCardExtn", [_extnPaymentCapture_CreditCardExtnUI],{
	// custom code here
});
});

