scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/return/search/ReturnListScreenExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnListScreenExtnUI
){ 
	return _dojodeclare("extn.return.search.ReturnListScreenExtn", [_extnReturnListScreenExtnUI],{
	// custom code here
});
});

