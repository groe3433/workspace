scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/home/portlets/MyAlertsPortletExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnMyAlertsPortletExtnUI
){ 
	return _dojodeclare("extn.home.portlets.MyAlertsPortletExtn", [_extnMyAlertsPortletExtnUI],{
	// custom code here
});
});

