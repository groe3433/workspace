
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/cancel/CancelOrderListScreenExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnCancelOrderListScreenExtnUI
){ 
	return _dojodeclare("extn.order.cancel.CancelOrderListScreenExtn", [_extnCancelOrderListScreenExtnUI],{
	// custom code here
});
});

