
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/return/create/fulfillmentSummary/ReturnFSShippingGroupExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnFSShippingGroupExtnUI
){ 
	return _dojodeclare("extn.return.create.fulfillmentSummary.ReturnFSShippingGroupExtn", [_extnReturnFSShippingGroupExtnUI],{
	// custom code here
});
});

