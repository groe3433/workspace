


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/order/details/OrderPricingSummaryAdjustmentsExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnOrderPricingSummaryAdjustmentsExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.order.details.OrderPricingSummaryAdjustmentsExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.order.details.OrderPricingSummaryAdjustmentsExtn'

			
			
			
}
);
});

