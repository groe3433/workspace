scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/home/portlets/ReturnsPortletExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnsPortletExtnUI
){ 
	return _dojodeclare("extn.home.portlets.ReturnsPortletExtn", [_extnReturnsPortletExtnUI],{
	// custom code here
});
});

