
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/common/address/display/AddressDisplayExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnAddressDisplayExtnUI
){ 
	return _dojodeclare("extn.common.address.display.AddressDisplayExtn", [_extnAddressDisplayExtnUI],{
	// custom code here
});
});

