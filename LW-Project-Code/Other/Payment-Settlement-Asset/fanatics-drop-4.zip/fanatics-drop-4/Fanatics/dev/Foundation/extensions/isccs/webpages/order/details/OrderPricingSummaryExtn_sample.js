scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/details/OrderPricingSummaryExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderPricingSummaryExtnUI
){ 
	return _dojodeclare("extn.order.details.OrderPricingSummaryExtn", [_extnOrderPricingSummaryExtnUI],{
	// custom code here
});
});

