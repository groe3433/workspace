


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/return/create/lines/ReturnOrderLinesExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnOrderLinesExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.return.create.lines.ReturnOrderLinesExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.return.create.lines.ReturnOrderLinesExtn'

			
			
			
}
);
});

