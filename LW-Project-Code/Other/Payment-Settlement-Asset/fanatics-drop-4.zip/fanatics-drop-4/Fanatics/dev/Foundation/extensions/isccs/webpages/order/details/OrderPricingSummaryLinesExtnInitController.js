


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/order/details/OrderPricingSummaryLinesExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnOrderPricingSummaryLinesExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.order.details.OrderPricingSummaryLinesExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.order.details.OrderPricingSummaryLinesExtn'

			
			
			
}
);
});

