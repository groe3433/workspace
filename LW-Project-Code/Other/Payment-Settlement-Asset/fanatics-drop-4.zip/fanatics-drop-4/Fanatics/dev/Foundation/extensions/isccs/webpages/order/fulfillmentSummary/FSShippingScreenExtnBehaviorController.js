


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/order/fulfillmentSummary/FSShippingScreenExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnFSShippingScreenExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.order.fulfillmentSummary.FSShippingScreenExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.order.fulfillmentSummary.FSShippingScreenExtn'

			
			
			
}
);
});

