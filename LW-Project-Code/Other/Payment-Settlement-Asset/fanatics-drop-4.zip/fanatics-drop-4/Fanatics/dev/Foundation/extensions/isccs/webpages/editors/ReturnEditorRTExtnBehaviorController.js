


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/editors/ReturnEditorRTExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnEditorRTExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.editors.ReturnEditorRTExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.editors.ReturnEditorRTExtn'

			
			
			
}
);
});

