


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/return/search/ReturnListScreenExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnListScreenExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.return.search.ReturnListScreenExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.return.search.ReturnListScreenExtn'

			
			
			
}
);
});

