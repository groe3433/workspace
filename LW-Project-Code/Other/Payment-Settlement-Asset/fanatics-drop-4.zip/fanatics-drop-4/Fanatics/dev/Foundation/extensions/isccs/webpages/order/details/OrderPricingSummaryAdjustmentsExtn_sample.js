scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/details/OrderPricingSummaryAdjustmentsExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderPricingSummaryAdjustmentsExtnUI
){ 
	return _dojodeclare("extn.order.details.OrderPricingSummaryAdjustmentsExtn", [_extnOrderPricingSummaryAdjustmentsExtnUI],{
	// custom code here
});
});

