


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/return/details/ReturnSummaryLinesExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnSummaryLinesExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.return.details.ReturnSummaryLinesExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.return.details.ReturnSummaryLinesExtn'

			
			
			
			
			
						,

			
			
			 mashupRefs : 	[
	 		{
		 mashupRefId : 			'getCompleteOrderLineList'
,
		 mashupId : 			'ReturnSummaryLines_getCompleteOrderLineList'
,
		 extnType : 			'MODIFY'

	}

	]

}
);
});

