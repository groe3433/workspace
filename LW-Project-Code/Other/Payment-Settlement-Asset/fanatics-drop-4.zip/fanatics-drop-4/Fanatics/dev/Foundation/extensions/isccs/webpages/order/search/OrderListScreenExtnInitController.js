


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/order/search/OrderListScreenExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnOrderListScreenExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.order.search.OrderListScreenExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.order.search.OrderListScreenExtn'

			
			
			
}
);
});

