scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/details/OrderPricingSummaryLinesExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderPricingSummaryLinesExtnUI
){ 
	return _dojodeclare("extn.order.details.OrderPricingSummaryLinesExtn", [_extnOrderPricingSummaryLinesExtnUI],{
	// custom code here
});
});

