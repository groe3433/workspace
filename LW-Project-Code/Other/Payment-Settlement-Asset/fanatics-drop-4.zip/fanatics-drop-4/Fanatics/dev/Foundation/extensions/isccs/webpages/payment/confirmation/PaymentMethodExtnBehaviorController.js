


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/payment/confirmation/PaymentMethodExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnPaymentMethodExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.payment.confirmation.PaymentMethodExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.payment.confirmation.PaymentMethodExtn'

			
			
			
}
);
});

