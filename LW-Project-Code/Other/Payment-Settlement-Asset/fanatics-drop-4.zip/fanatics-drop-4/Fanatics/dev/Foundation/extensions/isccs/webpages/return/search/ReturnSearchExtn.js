
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/return/search/ReturnSearchExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnSearchExtnUI
){ 
	return _dojodeclare("extn.return.search.ReturnSearchExtn", [_extnReturnSearchExtnUI],{
	// custom code here
});
});

