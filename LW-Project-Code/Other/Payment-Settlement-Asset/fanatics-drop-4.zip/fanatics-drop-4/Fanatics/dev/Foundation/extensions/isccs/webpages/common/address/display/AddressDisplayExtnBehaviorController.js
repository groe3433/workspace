


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/common/address/display/AddressDisplayExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnAddressDisplayExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.common.address.display.AddressDisplayExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.common.address.display.AddressDisplayExtn'

			
			
			
}
);
});

