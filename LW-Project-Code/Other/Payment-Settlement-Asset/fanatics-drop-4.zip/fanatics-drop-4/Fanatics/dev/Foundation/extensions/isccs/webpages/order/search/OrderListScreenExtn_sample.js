scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/search/OrderListScreenExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderListScreenExtnUI
){ 
	return _dojodeclare("extn.order.search.OrderListScreenExtn", [_extnOrderListScreenExtnUI],{
	// custom code here
});
});

