scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/about/AboutPopupExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnAboutPopupExtnUI
){ 
	return _dojodeclare("extn.about.AboutPopupExtn", [_extnAboutPopupExtnUI],{
	// custom code here
});
});

