scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/editors/HomeEditorRTExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnHomeEditorRTExtnUI
){ 
	return _dojodeclare("extn.editors.HomeEditorRTExtn", [_extnHomeEditorRTExtnUI],{
	// custom code here
});
});

