
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/return/create/lines/ReturnOrderLinesExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnReturnOrderLinesExtnUI
){ 
	return _dojodeclare("extn.return.create.lines.ReturnOrderLinesExtn", [_extnReturnOrderLinesExtnUI],{
	// custom code here
});
});

