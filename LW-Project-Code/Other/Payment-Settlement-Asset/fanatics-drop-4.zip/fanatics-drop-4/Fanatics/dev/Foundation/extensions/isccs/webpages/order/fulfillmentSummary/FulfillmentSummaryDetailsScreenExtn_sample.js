
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/fulfillmentSummary/FulfillmentSummaryDetailsScreenExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnFulfillmentSummaryDetailsScreenExtnUI
){ 
	return _dojodeclare("extn.order.fulfillmentSummary.FulfillmentSummaryDetailsScreenExtn", [_extnFulfillmentSummaryDetailsScreenExtnUI],{
	// custom code here
});
});

