
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/common/address/capture/AddressCapturePageExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnAddressCapturePageExtnUI
){ 
	return _dojodeclare("extn.common.address.capture.AddressCapturePageExtn", [_extnAddressCapturePageExtnUI],{
	// custom code here
});
});

