scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/orderHold/ResolveHoldExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnResolveHoldExtnUI
){ 
	return _dojodeclare("extn.order.orderHold.ResolveHoldExtn", [_extnResolveHoldExtnUI],{
	// custom code here
});
});

