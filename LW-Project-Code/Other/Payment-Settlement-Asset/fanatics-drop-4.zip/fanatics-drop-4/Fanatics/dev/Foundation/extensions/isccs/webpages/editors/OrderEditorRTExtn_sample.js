
scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/editors/OrderEditorRTExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderEditorRTExtnUI
){ 
	return _dojodeclare("extn.editors.OrderEditorRTExtn", [_extnOrderEditorRTExtnUI],{
	// custom code here
});
});

