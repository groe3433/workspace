scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/fulfillmentSummary/FSShippingScreenExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnFSShippingScreenExtnUI
){ 
	return _dojodeclare("extn.order.fulfillmentSummary.FSShippingScreenExtn", [_extnFSShippingScreenExtnUI],{
	// custom code here
});
});

