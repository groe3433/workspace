


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/about/AboutPopupExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnAboutPopupExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.about.AboutPopupExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.about.AboutPopupExtn'

			
			
			
}
);
});

