


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/order/orderHold/ResolveHoldExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnResolveHoldExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.order.orderHold.ResolveHoldExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.order.orderHold.ResolveHoldExtn'

			
			
			
}
);
});

