scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/home/portlets/CustomerPortletExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnCustomerPortletExtnUI
){ 
	return _dojodeclare("extn.home.portlets.CustomerPortletExtn", [_extnCustomerPortletExtnUI],{
	// custom code here
});
});

