


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/home/portlets/ProductPortletExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnProductPortletExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.home.portlets.ProductPortletExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.home.portlets.ProductPortletExtn'

			
			
			
}
);
});

