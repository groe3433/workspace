scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/home/portlets/OrderPortletExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderPortletExtnUI
){ 
	return _dojodeclare("extn.home.portlets.OrderPortletExtn", [_extnOrderPortletExtnUI],{
	// custom code here
});
});

