scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/common/notes/NoteDisplayExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnNoteDisplayExtnUI
){ 
	return _dojodeclare("extn.common.notes.NoteDisplayExtn", [_extnNoteDisplayExtnUI],{
	// custom code here
});
});

