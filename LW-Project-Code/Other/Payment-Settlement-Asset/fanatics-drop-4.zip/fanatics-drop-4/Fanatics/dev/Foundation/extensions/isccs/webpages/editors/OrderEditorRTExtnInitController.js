


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/editors/OrderEditorRTExtn","scbase/loader!sc/plat/dojo/controller/ExtnScreenController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnOrderEditorRTExtn
			 ,
			    _scExtnScreenController
){

return _dojodeclare("extn.editors.OrderEditorRTExtnInitController", 
				[_scExtnScreenController], {

			
			 screenId : 			'extn.editors.OrderEditorRTExtn'

			
			
			
}
);
});

