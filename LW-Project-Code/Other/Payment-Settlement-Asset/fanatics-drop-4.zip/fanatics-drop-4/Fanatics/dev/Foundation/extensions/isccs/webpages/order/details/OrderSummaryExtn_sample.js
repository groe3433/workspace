scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/details/OrderSummaryExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderSummaryExtnUI
){ 
	return _dojodeclare("extn.order.details.OrderSummaryExtn", [_extnOrderSummaryExtnUI],{
	// custom code here
});
});

