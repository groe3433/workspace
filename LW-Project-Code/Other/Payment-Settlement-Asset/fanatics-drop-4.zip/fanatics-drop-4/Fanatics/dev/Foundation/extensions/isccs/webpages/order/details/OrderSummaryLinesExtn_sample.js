scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!extn/order/details/OrderSummaryLinesExtnUI"]
,
function(			 
			    _dojodeclare
			 ,
			    _extnOrderSummaryLinesExtnUI
){ 
	return _dojodeclare("extn.order.details.OrderSummaryLinesExtn", [_extnOrderSummaryLinesExtnUI],{
	// custom code here
});
});

