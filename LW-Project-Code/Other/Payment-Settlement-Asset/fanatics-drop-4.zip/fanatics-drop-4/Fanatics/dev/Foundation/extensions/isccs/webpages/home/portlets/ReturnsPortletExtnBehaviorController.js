


scDefine(["scbase/loader!dojo/_base/declare","scbase/loader!dojo/_base/kernel","scbase/loader!dojo/text","scbase/loader!extn/home/portlets/ReturnsPortletExtn","scbase/loader!sc/plat/dojo/controller/ExtnServerDataController"]
 , function(			 
			    _dojodeclare
			 ,
			    _dojokernel
			 ,
			    _dojotext
			 ,
			    _extnReturnsPortletExtn
			 ,
			    _scExtnServerDataController
){

return _dojodeclare("extn.home.portlets.ReturnsPortletExtnBehaviorController", 
				[_scExtnServerDataController], {

			
			 screenId : 			'extn.home.portlets.ReturnsPortletExtn'

			
			
			
}
);
});

