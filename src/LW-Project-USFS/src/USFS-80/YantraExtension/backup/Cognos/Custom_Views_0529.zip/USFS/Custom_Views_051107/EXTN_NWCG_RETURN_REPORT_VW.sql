CREATE OR REPLACE VIEW EXTN_NWCG_RETURN_REPORT_VW
("RECEIPT NO", ITEM_ID, ITEM_DESCRIPTION, UOM, SERIAL_NO, 
 QUANTITY_RETURNED, QUANTITY_RFI, QUANTITY_NRFI, QUANTITY_UNSERVICED, QUANTITY_UNSERVICED_NWT, 
 QUANTITY_WORDERED, "INCIDENT NO", INCIDENT_NAME, RETURN_DATE, EXTN_RETURN_COMMENTS, 
 INSPECTION_COMMENTS, INCIDENT_OTHER_ACCT_CODE, INCIDENT_BLM_ACCT_CODE, INCIDENT_FS_ACCT_CODE, OVERRIDE_CODE, 
 UNIT_PRICE, YEAR, "CACHE ID", COMPANY, RETURN_TO_ADDRESS1, 
 RETURN_TO_ADDRESS2, RETURN_TO_CITY, RETURN_TO_STATE, RETURN_TO_ZIP, SHIP_TO_COMPANY, 
 SHIP_TO_ADDRESS1, SHIP_TO_ADDRESS2, SHIP_TO_CITY, SHIP_TO_STATE, SHIP_TO_ZIP)
AS 
select distinct rh.receipt_no "RECEIPT NO",rl.item_id,yi.description "ITEM_DESCRIPTION",yi.uom,rl.serial_no,
        (select sum(c1.quantity_returned)
		from nwcg_incident_return c1
		where c1.item_id = rl.item_id
		  and rtrim(c1.incident_no) = rtrim(nio.incident_no)
		  and rtrim(c1.incident_year) = rtrim(nio.year)
		  and rtrim(c1.cache_id) = rtrim(nio.primary_cache_id)
		  and to_char(c1.date_issued,'MM/DD/YYYY') = to_char(rh.receipt_date,'MM/DD/YYYY'))"QUANTITY_RETURNED",
		(select sum(c1.quantity_rfi)
		from nwcg_incident_return c1
		where c1.item_id = rl.item_id
		  and rtrim(c1.incident_no) = rtrim(nio.incident_no)
		  and rtrim(c1.incident_year) = rtrim(nio.year)
		  and rtrim(c1.cache_id) = rtrim(nio.primary_cache_id)
		  and to_char(c1.date_issued,'MM/DD/YYYY') = to_char(rh.receipt_date,'MM/DD/YYYY'))"QUANTITY_RFI",
		(select sum(c1.quantity_nrfi)
		from nwcg_incident_return c1
		where c1.item_id = rl.item_id
		  and rtrim(c1.incident_no) = rtrim(nio.incident_no)
		  and rtrim(c1.incident_year) = rtrim(nio.year)
		  and rtrim(c1.cache_id) = rtrim(nio.primary_cache_id)
		  and to_char(c1.date_issued,'MM/DD/YYYY') = to_char(rh.receipt_date,'MM/DD/YYYY'))"QUANTITY_NRFI",
		(select sum(c1.quantity_uns_return)
		from nwcg_incident_return c1
		where c1.item_id = rl.item_id
		  and rtrim(c1.incident_no) = rtrim(nio.incident_no)
		  and rtrim(c1.incident_year) = rtrim(nio.year)
		  and rtrim(c1.cache_id) = rtrim(nio.primary_cache_id)
		  and to_char(c1.date_issued,'MM/DD/YYYY') = to_char(rh.receipt_date,'MM/DD/YYYY'))"QUANTITY_UNSERVICED",
		(select sum(c1.quantity_uns_nwt_return)
		from nwcg_incident_return c1
		where c1.item_id = rl.item_id
		  and rtrim(c1.incident_no) = rtrim(nio.incident_no)
		  and rtrim(c1.incident_year) = rtrim(nio.year)
		  and rtrim(c1.cache_id) = rtrim(nio.primary_cache_id)
		  and to_char(c1.date_issued,'MM/DD/YYYY') = to_char(rh.receipt_date,'MM/DD/YYYY'))"QUANTITY_UNSERVICED_NWT",
		(select sum(c3.quantity_allocated)
		from yfs_work_order c3
		where rtrim(c3.item_id) = rtrim(rl.item_id)
		  and rtrim(c3.extn_incident_no) = rtrim(nio.incident_no)
		  and rtrim(c3.extn_incident_year) = rtrim(nio.year))"QUANTITY_WORDERED",
	    nio.incident_no "INCIDENT NO",nio.incident_name,rh.receipt_date "RETURN_DATE",
		rh.extn_return_comments,rl.inspection_comments,
		nio.incident_other_acct_code,nio.incident_blm_acct_code,
		nio.incident_fs_acct_code,nio.override_code,yi.unit_cost "UNIT_PRICE",nio.year,nio.primary_cache_id "CACHE ID",
        d.company,d.address_line1"RETURN_TO_ADDRESS1",d.address_line2 "RETURN_TO_ADDRESS2",
	    d.city "RETURN_TO_CITY",d.state "RETURN_TO_STATE",d.zip_code "RETURN_TO_ZIP",
		f.company "SHIP_TO_COMPANY",f.address_line1"SHIP_TO_ADDRESS1",f.address_line2 "SHIP_TO_ADDRESS2",
	    f.city "SHIP_TO_CITY",f.state "SHIP_TO_STATE",f.zip_code "SHIP_TO_ZIP"
	from yfs_receipt_header rh,yfs_receipt_line rl,nwcg_incident_order nio,yfs_item yi,
	     yfs_person_info d,yfs_organization e,yfs_person_info f
  where rtrim(nio.incident_no) = rtrim(rh.extn_incident_no)
   and rtrim(nio.year) = rtrim(rh.extn_incident_year)
   and rh.receipt_header_key = rl.receipt_header_key
   and rl.item_id = yi.item_id
   and rtrim(nio.primary_cache_id) = rtrim(e.organization_code)
   and e.corporate_address_key = d.person_info_key
   and nio.person_info_shipto_key = f.person_info_key
   and rh.extn_is_return_receipt = 'Y';


