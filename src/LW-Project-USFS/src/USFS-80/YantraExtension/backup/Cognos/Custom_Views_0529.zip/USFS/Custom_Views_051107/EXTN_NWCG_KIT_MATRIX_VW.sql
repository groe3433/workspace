CREATE OR REPLACE VIEW EXTN_NWCG_KIT_MATRIX_VW
(KIT_ITEM_KEY, PARENT_ITEM_KEY, "KIT ID", PARENT_QTY_RFI, PARENT_QTY_MIN, 
 PARENT_QTY_MAX, PARENT_DESCRIPTION, PARENT_UNIT_COST, CHILD_ITEM_KEY, "COMPONENT ITEM", 
 CHILD_QTY_RFI, CHILD_QTY_MIN, CHILD_QTY_MAX, CHILD_QTY_ALLOC, CHILD_DESCRIPTION, 
 CHILD_UOM, CHILD_UNIT_COST, KIT_QUANTITY, LOCKID, CREATETS, 
 MODIFYTS, CREATEUSERID, MODIFYUSERID, CREATEPROGID, MODIFYPROGID)
AS 
select KI.KIT_ITEM_KEY,KI.ITEM_KEY "PARENT_ITEM_KEY",P.ITEM_ID "KIT ID",
(select sum(yli.quantity-(yli.hard_alloc_qty+yli.soft_alloc_qty))
from yfs_location_inventory yli, yfs_inventory_item yii
where yli.inventory_item_key = yii.inventory_item_key
  and yii.item_id = P.item_id )  "PARENT_QTY_RFI",
(select im.lead_time_level1_qty from yfs_inventory_monitor_rules im, yna_item_vw iv1
 where iv1.item_id = P.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "PARENT_QTY_MIN",
(select im.lead_time_level3_qty from yfs_inventory_monitor_rules im, yna_item_vw iv1
 where iv1.item_id = P.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "PARENT_QTY_MAX",
       P.DESCRIPTION "PARENT_DESCRIPTION",
       P.UNIT_COST "PARENT_UNIT_COST",KI.COMPONENT_ITEM_KEY "CHILD_ITEM_KEY",C.ITEM_ID "COMPONENT ITEM",
(select sum(yli.quantity-(yli.hard_alloc_qty+yli.soft_alloc_qty))
from yfs_location_inventory yli, yfs_inventory_item yii
where yli.inventory_item_key = yii.inventory_item_key
  and yii.item_id = C.item_id )  "CHILD_QTY_RFI",
(select im.lead_time_level1_qty from yfs_inventory_monitor_rules im, yna_item_vw iv1
 where iv1.item_id = C.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "CHILD_QTY_MIN",
(select im.lead_time_level3_qty from yfs_inventory_monitor_rules im, yna_item_vw iv1
 where iv1.item_id = C.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "CHILD_QTY_MAX",
 (select sum(yid.quantity)
from yfs_inventory_demand yid, yfs_inventory_item yii
where yid.inventory_item_key = yii.inventory_item_key
  and yii.item_id = C.item_id
  and yid.demand_type = 'ALLOCATED') "CHILD_QTY_ALLOC",
	   C.DESCRIPTION "CHILD_DESCRIPTION",
	   C.UOM "CHILD_UOM",C.UNIT_COST "CHILD_UNIT_COST",KI.KIT_QUANTITY,KI.LOCKID,KI.CREATETS,KI.MODIFYTS,KI.CREATEUSERID,
	   KI.MODIFYUSERID,KI.CREATEPROGID,KI.MODIFYPROGID
from yfs_item C, yfs_kit_item KI, yfs_item P
where C.ITEM_KEY = KI.COMPONENT_ITEM_KEY
and KI.ITEM_KEY = P.ITEM_KEY;


