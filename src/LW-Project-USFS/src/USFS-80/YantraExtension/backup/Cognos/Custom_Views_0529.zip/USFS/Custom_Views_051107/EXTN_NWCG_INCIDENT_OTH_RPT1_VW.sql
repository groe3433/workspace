CREATE OR REPLACE VIEW EXTN_NWCG_INCIDENT_OTH_RPT1_VW
(ITEM_ID, CLASS, ITEM_DESCRIPTION, UOM, QTY_AS_ITEM, 
 QTY_AS_KITS, TRANSFER_IN, TRANSFERRED_IN_AS_KITS, PARTS_USED, RCD_ITEMS, 
 RCD_AS_KITS, TRANSFER_OUT, TRANSFERRED_OUT_AS_KITS, QTY_WO, QTY_UNSER, 
 QTY_UNSER_NWT, EXTN_CACHE_SHIP_ACCT_CODE, SA_OVERRIDE_CODE, UNIT_PRICE, "INCIDENT NO", 
 EXTN_INCIDENT_NAME, "OTHER ACCT CODE", "BLM ACCT CODE", "FS ACCT CODE", EXTN_OVERRIDE_CODE, 
 YEAR, "CACHE ID")
AS 
select irb.item_id,yi.tax_product_code "CLASS",yi.description "ITEM_DESCRIPTION",yi.uom,
(select sum(ol.shipped_quantity) from yfs_order_line ol, yfs_order_header oh
where oh.extn_incident_no = m.incident_no
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type = '0001'
  and rtrim(oh.ship_node) = rtrim(m.primary_cache_id)
  and ol.item_id = irb.item_id ) "QTY_AS_ITEM",
(select sum(a1.kit_quantity *
(select sum(ol.shipped_quantity)
  from yfs_order_line ol,yfs_order_header oh,yfs_item c2,yfs_kit_item yki
 where oh.extn_incident_no = m.incident_no
   and oh.extn_incident_year = m.year
   and oh.order_header_key = ol.order_header_key
   and oh.document_type = '0001'
   and c2.item_id =  irb.item_id
   and yki.component_item_key = c2.item_key
   and ol.item_id = (select item_id from yfs_item where item_key = yki.item_key)
   and rtrim(oh.ship_node) = rtrim(m.primary_cache_id)))
from yfs_kit_item a1,yfs_item c1
where c1.item_id = irb.item_id
  and a1.component_item_key = c1.item_key
  and c1.organization_code = 'NWCG') "QTY_AS_KITS",
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh
where rtrim(oh.extn_to_incident_no) = rtrim(m.incident_no)
  and rtrim(oh.extn_to_incident_year) = rtrim(m.year)
  and oh.order_header_key = ol.order_header_key
  and oh.document_type like '0008%'
  and ol.item_id = irb.item_id) "TRANSFER_IN",
(select sum(a1.kit_quantity *
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh,yfs_item c2,yfs_kit_item yki
where rtrim(oh.extn_to_incident_no) = rtrim(m.incident_no)
  and rtrim(oh.extn_to_incident_year) = rtrim(m.year)
  and oh.order_header_key = ol.order_header_key
  and oh.document_type like '0008%'
  and c2.item_id =  irb.item_id
  and yki.component_item_key = c2.item_key
  and ol.item_id = (select item_id from yfs_item where item_key = yki.item_key)))
from yfs_kit_item a1,yfs_item c1
where c1.item_id = irb.item_id
  and a1.component_item_key = c1.item_key
  and c1.organization_code = 'NWCG') "TRANSFERRED_IN_AS_KITS",
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh
where oh.extn_incident_no = m.incident_no
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type = '0001'
  and rtrim(oh.ship_node) = rtrim(m.primary_cache_id)
  and oh.order_type like '%Refurb%'
  and ol.item_id = irb.item_id  ) "PARTS_USED",
(select sum(rl.quantity) from yfs_receipt_line rl,yfs_receipt_header rh,nwcg_incident_return nir
where rh.receipt_header_key = rl.receipt_header_key
  and rtrim(rh.receivingnode_key) = rtrim(m.primary_cache_id)
  and rh.extn_incident_no = m.incident_no
  and rh.extn_incident_year = m.year
  and rh.document_type = '0010'
  and rl.item_id = irb.item_id
  and nir.incident_no = m.incident_no
  and nir.incident_year = m.year
  and nir.item_id = irb.item_id
  and nir.received_as_component = 'N') "RCD_ITEMS",
(select sum(rl.quantity) from yfs_receipt_line rl,yfs_receipt_header rh,nwcg_incident_return nir
where rh.receipt_header_key = rl.receipt_header_key
  and rtrim(rh.receivingnode_key) = rtrim(m.primary_cache_id)
  and rh.extn_incident_no = m.incident_no
  and rh.extn_incident_year = m.year
  and rh.document_type = '0010'
  and rl.item_id = irb.item_id
  and nir.incident_no = m.incident_no
  and nir.incident_year = m.year
  and nir.item_id = irb.item_id
  and nir.received_as_component = 'Y') "RCD_AS_KITS",
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh
where rtrim(oh.extn_incident_no) = rtrim(m.incident_no)
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type like '0008%'
  and ol.item_id = irb.item_id) "TRANSFER_OUT",
(select sum(a1.kit_quantity *
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh,yfs_item c2,yfs_kit_item yki
where rtrim(oh.extn_incident_no) = rtrim(m.incident_no)
  and rtrim(oh.extn_incident_year) = rtrim(m.year)
  and oh.order_header_key = ol.order_header_key
  and oh.document_type like '0008%'
  and c2.item_id =  irb.item_id
  and yki.component_item_key = c2.item_key
  and ol.item_id = (select item_id from yfs_item where item_key = yki.item_key)))
from yfs_kit_item a1,yfs_item c1
where c1.item_id = irb.item_id
  and a1.component_item_key = c1.item_key
  and c1.organization_code = 'NWCG') "TRANSFERRED_OUT_AS_KITS",
(select sum(wo.quantity_allocated) from yfs_work_order wo
where wo.extn_incident_no = m.incident_no
  and wo.extn_incident_year = m.year
  and wo.document_type = '7001'
  and rtrim(wo.node_key) = rtrim(m.primary_cache_id)
  and rtrim(wo.item_id) = rtrim(irb.item_id)) "QTY_WO",
(select sum(nir.quantity_uns_return) from nwcg_incident_return nir
where rtrim(nir.incident_no) = rtrim(m.incident_no)
  and rtrim(nir.incident_year) = m.year
  and rtrim(nir.cache_id) = rtrim(m.primary_cache_id)
  and rtrim(nir.item_id) = rtrim(irb.item_id)) "QTY_UNSER",
(select sum(quantity_uns_nwt_return) from nwcg_incident_return nir
where rtrim(nir.incident_no) = rtrim(m.incident_no)
  and rtrim(nir.incident_year) = m.year
  and rtrim(nir.cache_id) = rtrim(m.primary_cache_id)
  and rtrim(nir.item_id) = rtrim(irb.item_id)) "QTY_UNSER_NWT",
(select max(extn_cache_ship_acct_code) from yfs_order_header oh,yfs_order_line ol
where oh.extn_incident_no = m.incident_no
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type = '0001'
  and rtrim(oh.ship_node) = rtrim(m.primary_cache_id)
  and ol.item_id = irb.item_id ) "EXTN_CACHE_SHIP_ACCT_CODE",
(select max(extn_sa_override_code) from yfs_order_header oh,yfs_order_line ol
where oh.extn_incident_no = m.incident_no
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type = '0001'
  and rtrim(oh.ship_node) = rtrim(m.primary_cache_id)
  and ol.item_id = irb.item_id ) "SA_OVERRIDE_CODE",  
(select max(ol.unit_price) from yfs_order_header oh,yfs_order_line ol
where oh.extn_incident_no = m.incident_no
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type = '0001'
  and rtrim(oh.ship_node) = rtrim(m.primary_cache_id)
  and ol.item_id = irb.item_id ) "UNIT_PRICE",
m.incident_no "INCIDENT NO",m.incident_name "EXTN_INCIDENT_NAME",m.incident_other_acct_code "OTHER ACCT CODE",
m.incident_blm_acct_code "BLM ACCT CODE",m.incident_fs_acct_code "FS ACCT CODE",
m.override_code "EXTN_OVERRIDE_CODE",m.year,m.primary_cache_id "CACHE ID"
from extn_nwcg_incident_rpt_base_vw irb,nwcg_incident_order m,yfs_item yi
where irb.incident_no = m.incident_no
  and irb.year = m.year
  and irb.item_id = yi.item_id;


