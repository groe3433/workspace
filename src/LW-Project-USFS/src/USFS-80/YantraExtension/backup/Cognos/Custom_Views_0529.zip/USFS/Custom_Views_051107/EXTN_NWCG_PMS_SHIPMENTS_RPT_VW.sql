CREATE OR REPLACE VIEW EXTN_NWCG_PMS_SHIPMENTS_RPT_VW
("CACHE ID", ACTUAL_SHIPMENT_DATE, ISSUES)
AS 
select x.shipnode_key "CACHE ID",x.actual_shipment_date,sum(x.issues1) "ISSUES" from
(select a.shipnode_key,a.actual_shipment_date,sum(b.ordered_qty * b.unit_price) "ISSUES1",b.item_id
from yna_shipment_vw a,yna_order_line_vw b,yfs_item yi,yfs_category yc, yfs_category_item yci
where a.document_type in ('0001','0006')
  and a.order_header_key = b.order_header_key
  and b.item_id = yi.item_id
  and yi.item_key = yci.item_key
  and yci.category_key = yc.category_key
  and yc.category_id = 'Publications'
group by a.shipnode_key,a.actual_shipment_date,b.item_id ) x
group by x.shipnode_key,x.actual_shipment_date;


