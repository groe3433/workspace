CREATE OR REPLACE VIEW EXTN_NWCG_STOCK_STATUS_RPT_VW
("CACHE ID", "ITEM ID", LOCATION_ID, ITEM_DESCRIPTION, UOM, 
 UNIT_COST, QTY_RFI, QTY_NRFI, QTY_RESD, QTY_KITS, 
 QTY_DUE, QTY_BACKORDER, QTY_ALLOC, QTY_WO, QTY_MIN, 
 QTY_MAX)
AS 
select a.node_key "CACHE ID",b.item_id "ITEM ID",a.location_id,iv.description "ITEM_DESCRIPTION",iv.uom,iv.unit_cost,
(select sum(a1.quantity - (a1.hard_alloc_qty+a1.soft_alloc_qty))
 from yfs_location_inventory a1,yfs_inventory_item b1
 where a1.inventory_item_key = b1.inventory_item_key
  and b1.item_id = b.item_id
  and a1.node_key = a.node_key
  and a1.location_id = a.location_id
  and a1.inventory_status = 'RFI') "QTY_RFI",
(select sum(a1.quantity - (a1.hard_alloc_qty+a1.soft_alloc_qty))
 from yfs_location_inventory a1,yfs_inventory_item b1
 where a1.inventory_item_key = b1.inventory_item_key
  and b1.item_id = b.item_id
  and a1.node_key = a.node_key
  and a1.location_id = a.location_id
  and a1.inventory_status = 'NRFI') "QTY_NRFI",
(select sum(ir.quantity)
 from yfs_inventory_reservation ir,yfs_inventory_item yii,yfs_item i
 where i.item_id = b.item_id
   and yii.item_id = b.item_id
   and ir.inventory_item_key = yii.inventory_item_key
   and ir.shipnode_key = a.node_key) "QTY_RESD",
(select sum(a1.kit_quantity *
(select sum(quantity) from yna_node_inventory_vw ni,yfs_item yi
 where ni.item_id = yi.item_id
   and yi.item_key = a1.item_key
   and ni.node_key = a.node_key
   and yi.organization_code = 'NWCG'))
from yfs_kit_item a1,yfs_item c1
where c1.kit_code != 'PK'
  and c1.item_id = b.item_id
  and a1.component_item_key = c1.item_key
  and c1.organization_code = 'NWCG') "QTY_KITS",
(select sum(l.ordered_qty)
from yfs_order_line l, yna_order_header_vw h
where l.item_id = b.item_id
  and l.order_header_key = h.order_header_key
  and h.document_type = '0005'
  and l.receiving_node = a.node_key) "QTY_DUE",
(select sum(l.extn_backordered_qty)
from yfs_order_line l, yna_order_header_vw h
where l.item_id = b.item_id
  and l.extn_back_order_flag = 'N'
  and l.order_header_key = h.order_header_key
  and h.document_type = '0005'
  and l.receiving_node = a.node_key) "QTY_BACKORDER",
(select sum(yid.quantity)
from yfs_inventory_demand yid, yfs_inventory_item yii
where yid.inventory_item_key = yii.inventory_item_key
  and yii.item_id = b.item_id
  and yid.demand_type = 'ALLOCATED') "QTY_ALLOC",
(select sum(w.quantity_allocated)
		from yfs_work_order w
		where rtrim(w.item_id) = rtrim(b.item_id)
		  and w.node_key = a.node_key)"QTY_WO",
(select im.lead_time_level1_qty from yfs_inventory_monitor_rules im, yfs_item iv1
 where iv1.item_id = b.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "QTY_MIN",
(select im.lead_time_level3_qty from yfs_inventory_monitor_rules im, yfs_item iv1
 where iv1.item_id = b.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "QTY_MAX"
from yfs_location_inventory a,yfs_inventory_item b,yfs_item iv
where a.inventory_item_key = b.inventory_item_key
  and b.item_id = iv.item_id
  and iv.organization_code = 'NWCG'
  and a.quantity > 0
group by a.node_key,b.item_id,a.location_id,iv.description,iv.uom,iv.unit_cost;


