CREATE OR REPLACE VIEW EXTN_NWCG_INCIDENT_RPT_BSRL_VW
(ITEM_ID, SERIAL_NO, EXTN_INCIDENT_NO, EXTN_INCIDENT_YEAR)
AS 
select m.item_id,m.serial_no,m.extn_incident_no,m.extn_incident_year 
from
(select a.item_id,b.serial_no,c.extn_incident_no,c.extn_incident_year
from yfs_shipment_line a, yfs_shipment_tag_serial b, yfs_order_header c
where a.shipment_line_key = b.shipment_line_key 
  and a.order_header_key = c.order_header_key
union  
select b.item_id,b.serial_no,a.extn_incident_no,a.extn_incident_year
from yfs_receipt_header a, yfs_receipt_line b,nwcg_incident_order nio,yfs_item yi
where a.receipt_header_key = b.receipt_header_key
  and b.item_id = yi.item_id
  and a.extn_incident_no = nio.incident_no
  and a.extn_incident_year = nio.year
  and yi.serialized_flag = 'Y') m;


