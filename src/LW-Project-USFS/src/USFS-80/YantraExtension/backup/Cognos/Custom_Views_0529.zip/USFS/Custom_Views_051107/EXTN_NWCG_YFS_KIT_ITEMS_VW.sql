CREATE OR REPLACE VIEW EXTN_NWCG_YFS_KIT_ITEMS_VW
(PARENT_ID, PARENT_SERIAL_NO, PARENT_DESC, COMP_ITEM_ID, COMPONENT_SERIAL_NO, 
 COMP_DESC, KIT_QUANTITY)
AS 
select c.item_id "PARENT_ID",
       (select serial_no from nwcg_trackable_item_h where item_id = c.item_id) "PARENT_SERIAL_NO",
       c.description "PARENT_DESC",
       a.item_id "COMP_ITEM_ID",
	   (select serial_no from nwcg_trackable_item_h where item_id = a.item_id) "COMPONENT_SERIAL_NO",
	   a.description "COMP_DESC",
	   b.kit_quantity
from yfs_item a,yfs_kit_item b,yfs_item c
where a.item_key = b.component_item_key 
  and b.item_key = c.item_key 
  and a.kit_code is not null;


