CREATE OR REPLACE VIEW EXTN_NWCG_PMS_RETURNS_RPT_VW
("CACHE ID", RECEIPT_DATE, RECEIPTS)
AS 
select x.receivingnode_key "CACHE ID",x.receipt_date,sum(x.receipts1) "RECEIPTS" from
(select a.receivingnode_key,a.receipt_date,sum(b.quantity * yi.unit_cost) "RECEIPTS1",b.item_id
from yfs_receipt_header a,yfs_receipt_line b,yfs_item yi,yfs_category yc, yfs_category_item yci
where a.document_type in ('0003','0010','0011')
  and a.receipt_header_key = b.receipt_header_key
  and b.item_id = yi.item_id
  and yi.item_key = yci.item_key
  and yci.category_key = yc.category_key
  and yc.category_id = 'Publications'
group by a.receivingnode_key,a.receipt_date,b.item_id ) x
group by x.receivingnode_key,x.receipt_date;


