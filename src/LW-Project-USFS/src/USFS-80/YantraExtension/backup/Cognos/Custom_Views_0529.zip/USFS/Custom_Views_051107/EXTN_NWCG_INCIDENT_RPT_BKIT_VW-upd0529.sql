CREATE OR REPLACE VIEW EXTN_NWCG_INCIDENT_RPT_BKIT_VW
(INCIDENT_NO, YEAR, "KIT ID", "COMPONENT ITEM", KIT_QUANTITY, 
 UNIT_COST)
AS 
select distinct m1.incident_no,m1.year,km."KIT ID",km."COMPONENT ITEM",km.KIT_QUANTITY,kyi.unit_cost
from
(select distinct nio.incident_no,nio.year,b.item_id,b.item_description
from yfs_order_header a, yfs_order_line b,nwcg_incident_order nio,yfs_item yi
where a.order_header_key = b.order_header_key
  and b.item_id = yi.item_id
  and a.extn_incident_no = nio.incident_no
  and a.extn_incident_year = nio.year
  and a.document_type in ('0001','0007.ex','0008.ex')) m1,extn_nwcg_kit_matrix_vw km, yfs_item kyi
where m1.item_id = km."KIT ID"
  and km."COMPONENT ITEM" = kyi.item_id;


