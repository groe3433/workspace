CREATE OR REPLACE VIEW EXTN_NWCG_REDISTRIBUTE_RPT_VW
("ORGANIZATION CODE", "CACHE ID", ITEM_ID, DESCRIPTION, UOM, 
 QTY_RFI, QTY_MAX)
AS 
select x.organization_code "ORGANIZATION CODE",x.node_key "CACHE ID",x.item_id,x.description,x.uom,x.qty_rfi,
(select nvl(im.lead_time_level3_qty,0) from yfs_inventory_monitor_rules im, yfs_item iv1
 where iv1.item_id = x.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "QTY_MAX"
from
(select a.node_key,b.organization_code,b.item_id,c.description,c.uom,sum(a.quantity - (a.hard_alloc_qty+a.soft_alloc_qty)) "QTY_RFI"
from yfs_location_inventory a,yfs_inventory_item b,yfs_item c
where a.inventory_status = 'RFI'
  and a.inventory_item_key = b.inventory_item_key
  and b.item_id = c.item_id
group by a.node_key,b.organization_code,b.item_id,c.description,c.uom) x;


