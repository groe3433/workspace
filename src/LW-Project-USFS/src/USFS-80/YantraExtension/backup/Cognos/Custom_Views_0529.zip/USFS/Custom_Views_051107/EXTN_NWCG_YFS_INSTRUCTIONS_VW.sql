CREATE OR REPLACE VIEW EXTN_NWCG_YFS_INSTRUCTIONS_VW
(TABLE_NAME, REFERENCE_KEY, INSTRUCTIONS)
AS 
select table_name,reference_key,ltrim(max(sys_connect_by_path(instruction_text,'~')),'~') as instructions
from   (select table_name,reference_key,
               instruction_text,
               row_number() over (partition by reference_key order by instruction_text) as curr,
               row_number() over (partition by reference_key order by instruction_text) -1 as prev
        from   yfs_instruction_detail)
group by table_name,reference_key
connect by prev = prior curr and reference_key = prior reference_key
start with curr = 1;


