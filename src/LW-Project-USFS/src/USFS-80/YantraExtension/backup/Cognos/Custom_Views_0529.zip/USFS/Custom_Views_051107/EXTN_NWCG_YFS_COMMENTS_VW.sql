CREATE OR REPLACE VIEW EXTN_NWCG_YFS_COMMENTS_VW
(TABLE_NAME, TABLE_KEY, COMMENTS)
AS 
select table_name,table_key,ltrim(max(sys_connect_by_path(note_text,'~')),'~') as comments
from   (select table_name,table_key,
               note_text,
               row_number() over (partition by table_key order by note_text) as curr,
               row_number() over (partition by table_key order by note_text) -1 as prev
        from   yfs_notes)
group by table_name,table_key
connect by prev = prior curr and table_key = prior table_key
start with curr = 1;


