CREATE OR REPLACE VIEW EXTN_NWCG_IE_CHD_21_VW
(PARENT_ITEM_KEY, CHILD_ITEM_KEY, PARENT_ITEM_ID, PARENT_DESCRIPTION, CHILD_ITEM_ID, 
 CHILD_DESCRIPTION, CHILD_QTY)
AS 
select yki.item_key as parent_item_key, yki.component_item_key as child_item_key, yi1.item_id as parent_item_id,
	   yi1.short_description as parent_description, yi2.item_id as child_item_id, 
	   yi2.short_description as child_description, yki.kit_quantity as child_qty
from
	yfs_kit_item yki, yfs_item yi1, yfs_item yi2
where
	yki.item_key = yi1.item_key and
	yki.component_item_key = yi2.item_key
order by yi1.item_id;


