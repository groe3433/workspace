CREATE OR REPLACE VIEW EXTN_NWCG_ACCT_TRANS_RPT_VW
("CACHE ID", "INCIDENT NO", INCIDENT_NAME, "TRANSACTION FISCAL YEAR", TRANS_DATE, 
 TRANSACTION_NO, TRANS_TYPE, DOCUMENT_TYPE, TRANSACTION_VALUE)
AS 
select x.cache_id "CACHE ID",x.incident_no "INCIDENT NO",x.incident_name,x.transaction_fiscal_year "TRANSACTION FISCAL YEAR",x.trans_date,
       x.transaction_no,x.trans_type,x.document_type,sum(x.item_trans_value) "TRANSACTION_VALUE"
from
(select cache_id,incident_no,incident_name,transaction_fiscal_year,trans_date,
       transaction_no,trans_type,document_type,item_id,(sum(trans_qty*unit_cost)) "ITEM_TRANS_VALUE"
from NWCG_BILLING_TRANSACTION
group by cache_id,incident_no,incident_name,transaction_fiscal_year,trans_date,transaction_no,trans_type,document_type,item_id) x
group by x.cache_id,x.incident_no,x.incident_name,x.transaction_fiscal_year,x.trans_date,x.transaction_no,x.trans_type,x.document_type;


