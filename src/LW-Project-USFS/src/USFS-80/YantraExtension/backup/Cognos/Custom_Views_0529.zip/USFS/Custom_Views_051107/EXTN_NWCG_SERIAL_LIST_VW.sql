CREATE OR REPLACE VIEW EXTN_NWCG_SERIAL_LIST_VW
(ITEM_ID, SERIAL_NO, EXTN_INCIDENT_NO, EXTN_INCIDENT_YEAR, ORDER_NO)
AS 
select a.item_id,b.serial_no,c.extn_incident_no,c.extn_incident_year,c.order_no
from yfs_shipment_line a, yfs_shipment_tag_serial b, yfs_order_header c
where a.shipment_line_key = b.shipment_line_key 
  and a.order_header_key = c.order_header_key;


