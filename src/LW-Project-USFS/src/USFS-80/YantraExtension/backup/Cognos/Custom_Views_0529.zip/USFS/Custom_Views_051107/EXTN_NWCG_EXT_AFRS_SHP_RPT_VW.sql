CREATE OR REPLACE VIEW EXTN_NWCG_EXT_AFRS_SHP_RPT_VW
("CACHE ID", ACTUAL_SHIPMENT_DATE, TOT_SHIPPED, TOT_POUNDS, TOT_CUBES, 
 TOT_SHIPPED_VALUE)
AS 
select x.shipnode_key "CACHE ID",x.actual_shipment_date,sum(x.shipped) "TOT_SHIPPED",sum(x.pounds) "TOT_POUNDS",
       sum(x.cubes) "TOT_CUBES",sum(x.shipped_value) "TOT_SHIPPED_VALUE" from
(select a.shipnode_key,a.actual_shipment_date,sum(b.quantity) "SHIPPED",sum(b.net_weight) "POUNDS",
       sum(b.quantity*c.unit_height*unit_length*unit_width) "CUBES",
	   sum(b.quantity * (select min(unit_price) from yfs_order_line where item_id = b.item_id)) "SHIPPED_VALUE",b.item_id
from yna_shipment_vw a,yna_shipment_line_vw b,yfs_item c
where a.document_type in ('0001')
  and a.shipment_key = b.shipment_key
  and b.item_id = c.item_id
group by a.shipnode_key,a.actual_shipment_date,b.item_id ) x
group by x.shipnode_key,x.actual_shipment_date;


