CREATE OR REPLACE VIEW EXTN_NWCG_INCIDENT_SKIT1_VW
(SUPER_PARENT, SUPER_PARENT_DESC, SUPER_PARENT_QTY_ISSUED, TRANSFER_IN, TRANSFER_OUT, 
 PARENT_ITEM, PARENT_DESC, PARENT_KIT_QTY, COMP_ITEM, ITEM_DESCRIPTION, 
 COMP_KIT_QTY, CLASS, UOM, "INCIDENT NO", EXTN_INCIDENT_NAME, 
 "OTHER ACCT CODE", "BLM ACCT CODE", "FS ACCT CODE", EXTN_OVERRIDE_CODE, YEAR, 
 "CACHE ID")
AS 
select k2_vw.super_parent,
(select description from yfs_item where item_id = k2_vw.super_parent) "SUPER_PARENT_DESC",
(select sum(ol.shipped_quantity) from yfs_order_line ol, yfs_order_header oh
where oh.extn_incident_no = m.incident_no
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type = '0001'
  and rtrim(oh.ship_node) = rtrim(m.primary_cache_id)
  and ol.item_id = k2_vw.super_parent ) "SUPER_PARENT_QTY_ISSUED",
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh
where rtrim(oh.extn_to_incident_no) = rtrim(m.incident_no)
  and rtrim(oh.extn_to_incident_year) = rtrim(m.year)
  and oh.order_header_key = ol.order_header_key
  and oh.document_type like '0008%'
  and ol.item_id = k2_vw.super_parent) "TRANSFER_IN",
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh
where rtrim(oh.extn_incident_no) = rtrim(m.incident_no)
  and oh.extn_incident_year = m.year
  and oh.order_header_key = ol.order_header_key
  and oh.document_type like '0008%'
  and ol.item_id = k2_vw.super_parent) "TRANSFER_OUT",
k2_vw.parent_item,
(select description from yfs_item where item_id = k2_vw.parent_item) "PARENT_DESC",
k2_vw.parent_kit_qty,k2_vw.comp_item,yi.description "ITEM_DESCRIPTION",k2_vw.comp_kit_qty,
yi.tax_product_code "CLASS",yi.uom,
m.incident_no "INCIDENT NO",m.incident_name "EXTN_INCIDENT_NAME",m.incident_other_acct_code "OTHER ACCT CODE",
m.incident_blm_acct_code "BLM ACCT CODE",m.incident_fs_acct_code "FS ACCT CODE",
m.override_code "EXTN_OVERRIDE_CODE",m.year,m.primary_cache_id "CACHE ID"
from extn_nwcg_incident_rpt_kit2_vw k2_vw,nwcg_incident_order m,yfs_item yi
where k2_vw.incident_no = m.incident_no
  and k2_vw.year = m.year
  and k2_vw.comp_item = yi.item_id;


