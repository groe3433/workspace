CREATE OR REPLACE VIEW EXTN_NWCG_INV_DISPOSAL_RPT_VW
("ITEM ID", INVENTORY_ITEM_KEY, DESCRIPTION, SERIALIZED_FLAG, UNIT_COST, 
 UOM, "CACHE ID", "TRANS TYPE", QUANTITY, SERIAL_NO, 
 LOCATION_ID, INVENTORY_STATUS, ENTERPRISE_CODE, "TRANS DATE", "DOCUMENT NO", 
 REFERENCE_2, REFERENCE_3, REFERENCE_4, REFERENCE_5, MODEL_NUMBER, 
 MANUFACTURER_SERIAL, ACQUISITION_COST, ACQUISITION_DATE, OWNER_UNIT_ID, INCIDENT_BLM_ACCT_CODE, 
 INCIDENT_FS_ACCT_CODE, INCIDENT_OTHER_ACCT_CODE, "DOCUMENT NUMBER", LAST_TRANSACTION_DATE, QTY_RFI)
AS 
select a.item_id "ITEM ID",a.inventory_item_key,c.description,c.serialized_flag,c.unit_cost,c.uom,
       b.node_key "CACHE ID",substr(b.reason_code,instr(b.reason_code,'-')+1) "TRANS TYPE",b.quantity,
       b.serial_no,b.location_id,b.inventory_status,b.enterprise_code,b.createts "TRANS DATE",
	   b.reference_1 "DOCUMENT NO",b.reference_2,b.reference_3,b.reference_4,b.reference_5,
	   d.lot_attribute_3 "MODEL_NUMBER",d.secondary_serial "MANUFACTURER_SERIAL",d.acquisition_cost,
       d.acquisition_date,d.owner_unit_id,d.blm_account_code "INCIDENT_BLM_ACCT_CODE",
	   d.fs_account_code "INCIDENT_FS_ACCT_CODE",d.other_account_code "INCIDENT_OTHER_ACCT_CODE",d.last_document_number "DOCUMENT NUMBER",
	   d.last_transaction_date,
      (select sum(a1.quantity - (a1.hard_alloc_qty+a1.soft_alloc_qty))
  from yfs_location_inventory a1
  where a1.inventory_item_key = a.inventory_item_key
  and a1.inventory_status = 'RFI'
  and a1.node_key = b.node_key) "QTY_RFI"
from yfs_inventory_item a,yfs_locn_inventory_audit b,yfs_item c,nwcg_trackable_item d
where a.inventory_item_key = b.inventory_item_key
  and b.reason_code like 'DISPOSAL%'
  and a.item_id = c.item_id
  and a.item_id = d.item_id (+);


