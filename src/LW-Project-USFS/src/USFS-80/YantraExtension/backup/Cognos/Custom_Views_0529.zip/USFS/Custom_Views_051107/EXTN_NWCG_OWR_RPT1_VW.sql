CREATE OR REPLACE VIEW EXTN_NWCG_OWR_RPT1_VW
("WORK ORDER NO", "CACHE ID", "ORDER NO", ORDER_HEADER_KEY, INCIDENT_NO, 
 FS_ACCT_CODE, BLM_ACCT_CODE, OTHER_ACCT_CODE, OVERRIDE_CODE, SHIP_ACCT_CODE, 
 EXTN_SA_OVERRIDE_CODE, EXTN_RA_OVERRIDE_CODE, INCIDENT_NAME, CUSTOMER_ID, YEAR, 
 CREATETS, ITEM_ID, UOM, SHIP_BY_DATE, WORDERED, 
 REPAIRED, OUTSD, DESCRIPTION, ACTIVITY_LOCATION_ID, ZONE_ID, 
 TOTAL_ADJUSTMENT_COST)
AS 
select distinct wo.work_order_no as "WORK ORDER NO", wo.node_key as "CACHE ID", oh.order_no as "ORDER NO",
	oh.order_header_key as order_header_key, wo.extn_incident_no as incident_no,
	wo.extn_fs_acct_code as fs_acct_code, wo.extn_blm_acct_code as blm_acct_code,
	wo.extn_other_acct_code as other_acct_code,
	oh.extn_override_code as override_code,oh.extn_cache_ship_acct_code as ship_acct_code,
	oh.extn_sa_override_code,oh.extn_ra_override_code,
	nio.incident_name as incident_name, nio.customer_id as customer_id,
	nio.year as year, wo.createts as createts, wo.item_id as item_id, wo.uom as uom, wo.ship_by_date as ship_by_date,
	wo.quantity_allocated as Wordered, wo.quantity_completed as repaired,
	(wo.quantity_allocated - wo.quantity_completed) as outsd, yi.short_description as description,
	woa.activity_location_id as activity_location_id, yl.zone_id as zone_id,
	oh.total_adjustment_amount as total_adjustment_cost
from yfs_work_order wo, yfs_order_header oh, nwcg_incident_order nio, yfs_item yi,
	 yfs_work_order_acty_dtl woa, yfs_location yl
where
	trim(wo.work_order_no) = oh.extn_refurb_wo(+) and
	wo.status != '1600' and
	wo.extn_incident_no = nio.incident_no and
	wo.extn_incident_year = nio.year and
	wo.item_id = trim(yi.item_id) and
	wo.work_order_key = woa.work_order_key and
	woa.activity_location_id = yl.location_id
order by wo.work_order_no;


