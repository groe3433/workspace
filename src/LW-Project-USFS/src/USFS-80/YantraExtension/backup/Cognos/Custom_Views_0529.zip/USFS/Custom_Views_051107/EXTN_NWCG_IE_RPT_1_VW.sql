CREATE OR REPLACE VIEW EXTN_NWCG_IE_RPT_1_VW
("ITEM ID", "ITEM DESCRIPTION", UOM, "CACHE ID", QUANTITY, 
 "LOCATION ID", SHIP_BY_DATE, QTY_AS_KITS)
AS 
select distinct yna_item_vw.item_id "ITEM ID", yna_item_vw.short_description "ITEM DESCRIPTION",
                yna_item_vw.uom, yna_inventory_in_node_vw.node_key "CACHE ID",
                yna_inventory_in_node_vw.quantity, yna_inventory_in_node_vw.location_id "LOCATION ID",
				yna_inventory_in_node_vw.ship_by_date,
(select sum(a1.kit_quantity *
(select sum(li.quantity)
  from yfs_location_inventory li, yfs_inventory_item ii,yfs_kit_item yki,yfs_item yi
 where li.location_id = yna_inventory_in_node_vw.location_id
   and li.node_key = yna_inventory_in_node_vw.node_key
   and li.inventory_status = 'RFI'
   and li.inventory_item_key = ii.inventory_item_key
   and yi.item_id = yna_item_vw.item_id
   and yki.component_item_key = yi.item_key 
   and ii.item_id =  (select item_id from yfs_item where item_key = yki.item_key)))
from yfs_kit_item a1,yfs_item c1
where c1.item_id = yna_item_vw.item_id
  and a1.component_item_key = c1.item_key
  and c1.organization_code = 'NWCG') "QTY_AS_KITS"				
from yna_item_vw, yna_inventory_in_node_vw 
where yna_item_vw.item_id = yna_inventory_in_node_vw.item_id and
      yna_inventory_in_node_vw.inventory_status = 'RFI' and
      yna_inventory_in_node_vw.ship_by_date is not null 
group by yna_item_vw.item_id, yna_item_vw.short_description, yna_item_vw.uom, yna_inventory_in_node_vw.node_key,
         yna_inventory_in_node_vw.quantity, yna_inventory_in_node_vw.location_id, yna_inventory_in_node_vw.ship_by_date
order by yna_item_vw.item_id;


