CREATE OR REPLACE VIEW EXTN_NWCG_IE_RPT_2_VW
(LOCATION_ID, SHIP_BY_DATE, CMP_QTY, CHILD_ITEM_ID, CHILD_DESCRIPTION, 
 NODE_KEY)
AS 
select chd22.location_id, chd22.ship_by_date, sum(chd22.quantity * chd21.child_qty) as cmp_qty, 
	chd21.child_item_id, chd21.child_description, chd22.node_key
from extn_nwcg_ie_chd_21_vw chd21, extn_nwcg_ie_chd_22_vw chd22
where
	chd21.parent_item_id = chd22.item_id
group by chd22.location_id, chd22.ship_by_date, chd21.child_item_id, chd21.child_description, chd22.node_key
order by chd21.child_item_id, chd22.location_id;


