CREATE OR REPLACE VIEW EXTN_NWCG_PO_BY_ITEM_RPT_VW
(ENTERPRISE_KEY, DOCUMENT_TYPE, "PURCHASE ORDER NO", EXTN_REQUISITION_NO, ORDER_DATE, 
 "SUPPLIER CODE", ORGANIZATION_NAME, PO_DATE, CARRIER_SERVICE_CODE, CARRIER_SERVICE, 
 REQ_DELIVERY_DATE, VENDOR_ID, FIRST_NAME, MIDDLE_NAME, LAST_NAME, 
 ADDRESS_LINE1, ADDRESS_LINE2, ADDRESS_LINE3, ADDRESS_LINE4, ADDRESS_LINE5, 
 ADDRESS_LINE6, CITY, COUNTRY, DAY_FAX_NO, DAY_PHONE, 
 ZIP_CODE, SHIP_TO_FIRST_NAME, SHIP_TO_MIDDLE_NAME, SHIP_TO_LAST_NAME, SHIP_TO_ADDRESS1, 
 SHIP_TO_ADDRESS2, SHIP_TO_ADDRESS3, SHIP_TO_ADDRESS4, SHIP_TO_ADDRESS5, SHIP_TO_ADDRESS6, 
 SHIP_TO_CITY, SHIP_TO_COUNTRY, SHIP_TO_DAY_FAX_NO, SHIP_TO_DAY_PHONE, SHIP_TO_ZIP_CODE, 
 "CACHE ID", PRIME_LINE_NO, "ITEM ID", ITEM_DESCRIPTION, UOM, 
 UNIT_COST, GLOBAL_ITEM_ID, EXTN_DOCUMENT_IDENTIFIER_CODE, EXTN_ROUTING_IDENTIFIER_CODE, EXTN_MEDIA_AND_STATUS_CODE, 
 EXTN_ACTIVITY_ADDRESS_CODE, EXTN_JDATE, EXTN_SUPPLEMENTARY_ADDRESS, EXTN_SIGNAL_CODE, EXTN_FUND_CODE, 
 EXTN_DIST_CODE, EXTN_PRIORITY_DESIGNATOR_CODE, EXTN_REQUIRED_DELIVERY_DATE, EXTN_ADVICE_CODE, EXTN_CNAME, 
 EXTN_CNO, EXTN_PROJ_CODE, EXTN_DRN_CODE, EXTN_OVERRIDE_CODE, EXTN_PO_SHIP_ACCT, 
 EXTN_FS_ACCT_CODE, EXTN_CACHE_SHIP_ACCT_CODE, EXTN_BLM_ACCT_CODE, EXTN_PRIORITY_CODE, EXTN_CACHE_RECEIVE_ACCT_CODE, 
 EXTN_CUST_ACCT_CODE, EXTN_INCIDENT_NO, EXTN_INCIDENT_NAME, EXTN_PRICE, EXTN_SA_OVERRIDE_CODE, 
 EXTN_RA_OVERRIDE_CODE, SUPPLIER_STD_PACK, ORDER_STATUS, PO_QTY, RECD_QTY, 
 ORDER_INSTRUCTIONS, ORDER_COMMENTS, ORDER_LINE_COMMENTS)
AS 
select distinct a.enterprise_key,a.document_type,a.order_no "PURCHASE ORDER NO",a.extn_requisition_no,
                a.order_date,a.seller_organization_code "SUPPLIER CODE",c.organization_name,
                to_date(to_char(a.createts,'DD-MON-YYYY')) "PO_DATE",
				a.carrier_service_code,
				(select carrier_service_desc from yfs_carrier_service where carrier_service_code = a.carrier_service_code) "CARRIER_SERVICE",
				a.req_delivery_date,a.vendor_id,
				e.first_name,e.middle_name,e.last_name,e.address_line1,e.address_line2,e.address_line3,e.address_line4,
	            e.address_line5,e.address_line6,e.city,e.country,e.day_fax_no,e.day_phone,e.zip_code,
				f.first_name "SHIP_TO_FIRST_NAME",f.middle_name "SHIP_TO_MIDDLE_NAME",f.last_name "SHIP_TO_LAST_NAME",f.address_line1 "SHIP_TO_ADDRESS1",
				f.address_line2 "SHIP_TO_ADDRESS2",f.address_line3 "SHIP_TO_ADDRESS3",f.address_line4 "SHIP_TO_ADDRESS4",
	            f.address_line5 "SHIP_TO_ADDRESS5",f.address_line6 "SHIP_TO_ADDRESS6",f.city "SHIP_TO_CITY",
				f.country "SHIP_TO_COUNTRY",f.day_fax_no "SHIP_TO_DAY_FAX_NO",f.day_phone "SHIP_TO_DAY_PHONE",f.zip_code "SHIP_TO_ZIP_CODE",
                a.receiving_node "CACHE ID",b.prime_line_no,b.item_id "ITEM ID",b.item_description,b.uom,d.unit_cost,
				d.global_item_id,a.extn_document_identifier_code,a.extn_routing_identifier_code,a.extn_media_and_status_code,
                a.extn_activity_address_code,a.extn_jdate,a.extn_supplementary_address,a.extn_signal_code,
                a.extn_fund_code,a.extn_dist_code,a.extn_priority_designator_code,a.extn_required_delivery_date,
                a.extn_advice_code,a.extn_cname,a.extn_cno,a.extn_proj_code,a.extn_drn_code,
				a.extn_override_code,a.extn_po_ship_acct,a.extn_fs_acct_code,a.extn_cache_ship_acct_code,
				a.extn_blm_acct_code,a.extn_priority_code,a.extn_cache_receive_acct_code,a.extn_cust_acct_code,
				a.extn_incident_no,a.extn_incident_name,a.extn_other_amount "EXTN_PRICE",
				a.extn_sa_override_code,a.extn_ra_override_code,
(select distinct supplier_standard_pack from nwcg_supplier_item where item_id = b.item_id and supplier_id = a.seller_organization_code) "SUPPLIER_STD_PACK",
(select max(status) from yfs_order_release_status where order_header_key = a.order_header_key) "ORDER_STATUS",
(select sum(ordered_qty)
   from yfs_order_line yl
  where yl.order_header_key = a.order_header_key
    and yl.item_id = b.item_id) "PO_QTY",
(select sum(received_quantity)
   from yfs_order_line yl
  where yl.order_header_key = a.order_header_key
    and yl.item_id = b.item_id) "RECD_QTY",
(select instructions from extn_nwcg_yfs_instructions_vw
 where reference_key = a.order_header_key
   and table_name = 'YFS_ORDER_HEADER') "ORDER_INSTRUCTIONS",
(select comments from extn_nwcg_yfs_comments_vw
 where table_key = a.order_header_key
   and table_name = 'YFS_ORDER_HEADER') "ORDER_COMMENTS",
(select comments from extn_nwcg_yfs_comments_vw
 where table_key = b.order_line_key
   and table_name = 'YFS_ORDER_LINE') "ORDER_LINE_COMMENTS"
  from yfs_order_header a, yfs_order_line b,yfs_organization c,yfs_item d,yfs_person_info e,yfs_person_info f
 where a.order_header_key = b.order_header_key
   and a.seller_organization_code = c.organization_code
   and b.item_id = d.item_id
   and c.contact_address_key = e.person_info_key
   and a.ship_to_key = f.person_info_key
   and a.document_type = '0005';


