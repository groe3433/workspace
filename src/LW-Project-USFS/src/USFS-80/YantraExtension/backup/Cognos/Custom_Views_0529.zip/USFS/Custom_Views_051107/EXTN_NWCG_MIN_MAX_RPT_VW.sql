CREATE OR REPLACE VIEW EXTN_NWCG_MIN_MAX_RPT_VW
("CACHE ID", "ITEM ID", DESCRIPTION, GLOBAL_ITEM_ID, QTY_RFI, 
 QTY_REQ, QTY_PO, QTY_BACKORDER, QTY_WO, QTY_MIN, 
 QTY_MAX, QTY_ISSUED, QTY_RESD, "SUPPLIER CODE")
AS 
select distinct a.node_key "CACHE ID",b.item_id "ITEM ID",c.description,c.global_item_id,
(a.quantity-(a.hard_alloc_qty+a.soft_alloc_qty)) "QTY_RFI",
(select sum(yl.ordered_qty) from yfs_order_line yl, yfs_order_header yh
where yh.order_header_key = yl.order_header_key
  and yh.document_type = '0005'
  and yh.extn_po_no is null
  and yl.item_id = b.item_id) "QTY_REQ",
(select sum(yl.ordered_qty) from yfs_order_line yl, yfs_order_header yh
where yh.order_header_key = yl.order_header_key
  and yh.document_type = '0005'
  and yh.extn_po_no is not null
  and yl.item_id = b.item_id) "QTY_PO",
(select sum(yl.extn_backordered_qty) from yfs_order_line yl, yfs_order_header yh
where yh.order_header_key = yl.order_header_key
  and yh.document_type = '0001'
  and yl.item_id = b.item_id) "QTY_BACKORDER",
(select sum(wo.quantity_requested) from yfs_work_order wo
where wo.document_type = '7001'
  and wo.item_id = b.item_id) "QTY_WO",
(select im.lead_time_level1_qty from yfs_inventory_monitor_rules im, yfs_item iv1
 where iv1.item_id = b.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "QTY_MIN",
(select im.lead_time_level3_qty from yfs_inventory_monitor_rules im, yfs_item iv1
 where iv1.item_id = b.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "QTY_MAX",
(select sum(yl.shipped_quantity) from yfs_order_line yl, yfs_order_header yh
where yh.order_header_key = yl.order_header_key
  and yh.document_type = '0001'
  and yl.item_id = b.item_id) "QTY_ISSUED",
(select sum(yid.quantity) from yna_inventory_demand_vw yid
where yid.demand_type = 'ALLOCATED'
  and yid.inventory_item_key = b.inventory_item_key) "QTY_RESD",
(select max(supplier_id) from nwcg_supplier_item
 where preferred = 'Y'
   and item_id = b.item_id) "SUPPLIER CODE"
from yfs_location_inventory a, yfs_inventory_item b,yfs_item c
where a.inventory_item_key = b.inventory_item_key
  and b.item_id = c.item_id
order by a.node_key,b.item_id;


