CREATE OR REPLACE VIEW EXTN_NWCG_OWR_RPT2_VW
(ORDER_HEADER_KEY, ITEM_ID, UNIT_COST, UOM, ORDERED_QTY, 
 TOTALPRICE)
AS 
select ol.order_header_key as order_header_key, ol.item_id as item_id, ol.unit_cost as unit_cost, ol.uom as uom, 
	ol.ordered_qty as ordered_qty, ol.unit_cost*ol.ordered_qty as totalPrice 
from yfs_order_header oh, yfs_order_line ol 
where 
oh.order_header_key = ol.order_header_key and
oh.extn_refurb_wo is not null;


