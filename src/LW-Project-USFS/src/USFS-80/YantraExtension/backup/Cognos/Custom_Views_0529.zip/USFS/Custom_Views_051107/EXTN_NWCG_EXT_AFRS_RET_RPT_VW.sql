CREATE OR REPLACE VIEW EXTN_NWCG_EXT_AFRS_RET_RPT_VW
(CACHE_ID, RECEIPT_DATE, TOT_RETURNED, TOT_POUNDS, TOT_CUBES, 
 TOT_RETURNED_VALUE)
AS 
select x.receivingnode_key "CACHE_ID",x.receipt_date,sum(x.returned) "TOT_RETURNED",sum(x.pounds) "TOT_POUNDS",
       sum(x.cubes) "TOT_CUBES",sum(x.returned_value) "TOT_RETURNED_VALUE" from
(select a.receivingnode_key,a.receipt_date,sum(b.quantity) "RETURNED",sum(b.net_weight) "POUNDS",
        sum(b.quantity*c.unit_height*unit_length*unit_width) "CUBES",
		sum(b.quantity * (select min(unit_price) from yfs_order_line where item_id = b.item_id)) "RETURNED_VALUE",b.item_id
from yfs_receipt_header a,yfs_receipt_line b,yfs_item c
where a.document_type in ('0003','0010','0011')
  and a.receipt_header_key = b.receipt_header_key
  and b.item_id = c.item_id
group by a.receivingnode_key,a.receipt_date,b.item_id) x
group by x.receivingnode_key,x.receipt_date;


