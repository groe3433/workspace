CREATE OR REPLACE VIEW EXTN_NWCG_CRITICAL_ITEM_VW
(ITEM_ID, UOM, ITEM_DESCRIPTION, "CACHE ID", QTY_RFI, 
 QTY_NRFI, PREV_DAY_USAGE, QUANTITY_WORDERED, GLOBAL_ITEM_ID, UNIT_COST, 
 "LOCAL CRITICAL", "NATIONAL CRITICAL", "GSA PREFERRED", QTY_MIN, QTY_MAX, 
 QTY_DUE)
AS 
select a.item_id,a.uom,a.item_description,a.node_key "CACHE ID",
(select sum(a1.quantity - (a1.hard_alloc_qty+a1.soft_alloc_qty))
  from yfs_location_inventory a1, yfs_inventory_item b1, yfs_item c1
  where a1.inventory_item_key = b1.inventory_item_key
  and b1.item_id = c1.item_id
  and b1.item_id = a.item_id
  and a1.inventory_status = 'RFI'
  and a1.node_key = a.node_key) "QTY_RFI",
(select sum(a1.quantity - (a1.hard_alloc_qty+a1.soft_alloc_qty))
  from yfs_location_inventory a1, yfs_inventory_item b1, yfs_item c1
  where a1.inventory_item_key = b1.inventory_item_key
  and b1.item_id = c1.item_id
  and b1.item_id = a.item_id
  and a1.inventory_status = 'NRFI'
  and a1.node_key = a.node_key) "QTY_NRFI",
(select sum(ol.ordered_qty) from yfs_order_line ol, yfs_order_header oh
where oh.order_header_key = ol.order_header_key
  and oh.document_type = '0001'
  and oh.ship_node = a.node_key
  and ol.item_id = a.item_id
  and to_char(ol.createts,'DD-MON-YYYY') = to_char(sysdate-1,'DD-MON-YYYY')) "PREV_DAY_USAGE",
(select sum(c3.quantity_allocated)
		from yfs_work_order c3
		where rtrim(c3.item_id) = rtrim(a.item_id)
		  and c3.node_key = a.node_key)"QUANTITY_WORDERED",
       c.global_item_id,c.unit_cost,
nvl((select extn_local_critical_item
   from yfs_item_node_defn
  where item_id = a.item_id
    and node = a.node_key),'N') "LOCAL CRITICAL",
 nvl(c.extn_nat_critical_item,'N') "NATIONAL CRITICAL",
 nvl((select preferred from nwcg_supplier_item where item_id = a.item_id and supplier_id = 'GSA'),'N') "GSA PREFERRED",
(select im.lead_time_level1_qty from yfs_inventory_monitor_rules im, yfs_item iv1
 where iv1.item_id = a.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "QTY_MIN",
(select im.lead_time_level3_qty from yfs_inventory_monitor_rules im, yfs_item iv1
 where iv1.item_id = a.item_id
   and iv1.inventory_monitor_rule = im.inventory_monitor_rule) "QTY_MAX",
(select sum(l.ordered_qty)
from yfs_order_line l, yna_order_header_vw h
where l.item_id = a.item_id
  and l.order_header_key = h.order_header_key
  and h.document_type = '0005'
  and l.receiving_node = a.node_key) "QTY_DUE"
from YNA_NODE_INVENTORY_NL_VW a,YFS_ITEM c
 where a.item_id = c.item_id
group by a.item_id,a.node_key,a.item_description,a.uom,c.global_item_id,c.unit_cost,c.extn_nat_critical_item;


