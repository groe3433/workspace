CREATE OR REPLACE VIEW EXTN_NWCG_OUT_SURPLUS_RPT_VW
(ITEM_ID, "CACHE ID", "INCIDENT NO", DESCRIPTION, UOM, 
 CLASS, "FS ACCT CODE", "BLM ACCT CODE", "OTHER ACCT CODE", OVERRIDE_CODE, 
 YEAR, QTY_OUT, UNIT_PRICE)
AS 
select a.item_id,a.cache_id "CACHE ID",a.incident_no "INCIDENT NO",
       b.description,b.uom,b.tax_product_code "CLASS",c.incident_fs_acct_code "FS ACCT CODE",
       c.incident_blm_acct_code "BLM ACCT CODE",c.incident_other_acct_code "OTHER ACCT CODE",c.override_code,c.year,
      (sum(a.quantity_shipped)-sum(a.quantity_returned)) "QTY_OUT",a.unit_price
from nwcg_incident_return a, yfs_item b,nwcg_incident_order c
where rtrim(a.incident_no) = rtrim(c.incident_no)
  --and rtrim(a.incident_year) = rtrim(c.year)
  and a.item_id = b.item_id
group by  a.item_id,a.cache_id,a.incident_no,b.description,b.uom,b.tax_product_code,c.incident_fs_acct_code,
       c.incident_blm_acct_code,c.incident_other_acct_code,c.override_code,c.year,a.unit_price;


