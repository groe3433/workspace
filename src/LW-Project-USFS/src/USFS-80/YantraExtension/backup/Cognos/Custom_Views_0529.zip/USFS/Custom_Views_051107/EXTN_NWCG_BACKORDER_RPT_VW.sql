CREATE OR REPLACE VIEW EXTN_NWCG_BACKORDER_RPT_VW
("CACHE ID", "INCIDENT NO", YEAR, EXTN_INCIDENT_NAME, ORDER_HEADER_KEY, 
 "ORDER NO", EXTN_REQUEST_NO, PRIME_LINE_NO, "ITEM ID", ITEM_SHORT_DESCRIPTION, 
 EXTN_BACKORDERED_QTY, UOM, "CUSTOMER ID", SHIPPING_UNIT_ID, CUSTOMER_NAME, 
 QTY_RFI, BACKORDER_TIME)
AS 
select nio.primary_cache_id "CACHE ID",yoh.extn_incident_no "INCIDENT NO",nio.year,yoh.extn_incident_name,yoh.order_header_key,
       yoh.order_no "ORDER NO",yol.extn_request_no,yol.prime_line_no,yol.item_id "ITEM ID",yol.item_short_description,
	   yol.extn_backordered_qty,yol.uom,yoh.bill_to_id "CUSTOMER ID",
	   nvl(yoh.ship_to_id,'****') "SHIPPING_UNIT_ID",
	   (select extn_customer_name from yfs_customer where customer_id = yoh.bill_to_id ) "CUSTOMER_NAME",
	   (select (sum(yli.quantity) - sum(yli.hard_alloc_qty + yli.soft_alloc_qty))
from yfs_location_inventory yli,yfs_inventory_item yii
where yli.inventory_item_key = yii.inventory_item_key
  and yii.item_id = yol.item_id) "QTY_RFI",yol.createts "BACKORDER_TIME"
from yfs_order_header yoh,nwcg_incident_order nio,yfs_order_line yol
where yoh.extn_incident_no = nio.incident_no
  and yoh.extn_incident_year = nio.year
  and yoh.order_header_key = yol.order_header_key
  and yol.extn_backordered_qty > 0;


